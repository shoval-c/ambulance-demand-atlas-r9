H3 R9 ambulance coverage research atlas

Five demonstrations and the original Tel Aviv–Yafo study. Each city CSV contains three records per H3 cell. Period-specific workload is an expected hourly rate. Neighboring cells share coverage, so never add the ambulance column to get fleet size. Staffing is a planning calculation, not an observed count of ambulance postings or an official recommendation.

New-city weekdays run Monday–Friday 06:00–19:00, with nights starting Monday–Friday 19:00 and ending next morning at 06:00. Friday sunset–Saturday civil dusk overrides overlapping weekday hours. Tel Aviv retains its original Sunday–Thursday convention.

For each period, inputs determine shares within the available source reporting areas. Each cell’s own demand sets its within-city rank. Each cell and its in-city neighbors comprise a catchment. We take its busiest modeled period and select the smallest whole number (minimum one) reaching 95% availability under Erlang B, assuming one hour of work per case-equivalent. Catchments overlap and crews can be shared. These estimates are not an operational dispatch or site-allocation plan.

The five new city datasets use percent-point weight assumptions shown in their individual maps. A driver_contribution_per_hour field is its contribution to the estimated rate of that cell during that period. Unit/period and data vintages are listed below. NYC precinct and London borough totals anchor subcity demand. Elsewhere the main anchor is citywide.

Greater London
1026706 / FY 2024/25 (April–March) / LAS Category 1–4 incidents in response-time reporting
Greater London, all 33 boroughs. The 2024/25 London Ambulance Service total is distributed to boroughs using their shares of recorded incidents in 2008/09. Within each borough the model uses 2021 census residents, residents aged 65+, workplace population, non-residential buildings and period-specific police-reported injury collisions in 2021–25. The 2021 workplace census was taken during pandemic restrictions. The historical borough split may have changed. Contains National Statistics data © Crown copyright and database right [2015]. Contains Ordnance Survey data © Crown copyright and database right [2015].
The model scales the 168-hour LAS weekly profile from 2008/09 to the 2024/25 volume. It uses local clock time and the dates of the 2024/25 financial year. Present-day hourly incident counts by hexagon are unavailable here.
London Ambulance Service’s 2008/09 all-incident borough totals and 168-hour citywide distribution describe historical demand. The 2024/25 Category 1–4 response-time incident count calibrates total volume. Census households and workplaces are from 21 March 2021 during pandemic restrictions. STATS19 measures police-reported injury road collisions only. Exposure windows use Europe/London, Monday–Friday 06:00–19:00 and weekday nights 19:00–06:00 the next day, with Friday sunset through Saturday civil dusk taking precedence. Solar events are calculated at 51.5074°N, 0.1278°W. Unmatched collision coordinates are excluded. Contains National Statistics data © Crown copyright and database right [2015]. Contains Ordnance Survey data © Crown copyright and database right [2015].
Weights in percent (weekday day, weekday night, Shabbat): [{"young": 23.0, "older": 20.0, "jobs": 44.0, "nonres": 4.0, "crashes": 9.0}, {"young": 40.0, "older": 30.0, "jobs": 12.0, "nonres": 4.0, "crashes": 14.0}, {"young": 36.0, "older": 28.0, "jobs": 18.0, "nonres": 5.0, "crashes": 13.0}]
GLA and ONS · London statistical boundaries, 2021 MSOAs — https://data.london.gov.uk/dataset/statistical-gis-boundary-files-for-london-20od9
ONS Census 2021 · TS007A usual residents by age — https://www.nomisweb.co.uk/datasets/c2021ts007a
ONS Census 2021 · WP001 workplace population — https://www.nomisweb.co.uk/sources/census_2021_wp
London Ambulance Service and GLA · 2008/09 weekly incident pattern and borough totals, tables 9.26–9.27 — https://data.london.gov.uk/dataset/focus-on-london-2000-2009-exp7p
London Ambulance Service NHS Trust · 2024/25 Annual Report, Category 1–4 response-time incident counts — https://www.londonambulance.nhs.uk/download/41281/?tmstv=1775189130
Department for Transport · STATS19 police-reported injury collisions, 2021–2025 — https://www.gov.uk/government/statistical-data-sets/road-safety-open-data
European Commission JRC · GHS-POP R2023A, 2020 epoch, 100 m — https://human-settlement.emergency.copernicus.eu/ghs_pop2023.php
European Commission JRC · GHS-BUILT-S R2023A, non-residential surface, 2020 epoch, 100 m — https://human-settlement.emergency.copernicus.eu/ghs_buS2023.php
Van Buuren et al. · demand-point constrained ambulance coverage — https://martinvanbuuren.nl/wp-content/uploads/2020/01/M.-van-Buuren-et-al.-Demand-point-constrained-EMS-vehicle-allocation-problems-for-regions.pdf

Paris
142565 / 2023 / Patients transported to hospital following fire-service attendance in Paris
Paris city proper, département 75. ORSNP reports 142,565 patients taken to hospital after fire-service attendance in Paris in 2023. This covers transports after these responses, excluding patients left at the scene and independent ambulance activity. One transported patient is treated as one unit of workload. Smaller-area census data, workplace activity, rail entries, buildings and international tourist zones estimate its local distribution. The tourist-zone measure is designated land area. Workplace jobs are available by arrondissement and apportioned to smaller areas. The city includes both the Bois de Boulogne and the Bois de Vincennes.
Citywide rates use the approximate 24-hour Paris fire-service patient profile (all attended patients) read from the chart on page 6 of the 2023 ORSNP report, normalized to the annual count. The same profile is used for every day of the week. Rail entries and the spatial weights vary by period.
Paris proper, including the Bois de Boulogne and Bois de Vincennes. The citywide annual anchor counts patients with an incident in department 75 who were transported by a fire-service or other vehicle after fire-service attendance. It excludes patients left on scene and responses outside the reporting services. ORSNP page 6 provides the all-days, all-victim hourly profile for Paris. The 24 graph readings were digitized approximately and normalized to sum to one. The APUR 2021 census supplies resident and age 65+ counts for all 992 IRIS. INSEE 2022 employment by workplace is distributed within each arrondissement by equal-area square metres of business and residential IRIS. Divers IRIS (woods, tracks, river and large miscellaneous areas) receive zero employment weight. Tourist_m2 is overlap with the 12 published international tourist-zone boundaries in the Paris Data file. It measures designated area, not footfall. Station_cells are estimated 2023 rail entries into matched in-boundary station complexes in each period. IDFM supplies entries only, excludes exits and transfers, and identifies 244 matched complexes across 239 H3 cells. Daily totals for each stop were distributed using the corresponding semester, service-day type, and station-hour profile. School breaks follow the Zone C calendar. The 04:00 service-day rollover is included. Friday sunset to Saturday civil dusk takes precedence; partial clock hours split in proportion to duration. The day and night windows cover Monday to Friday 06:00–19:00 and 19:00–06:00 next day after that override. These rail volumes measure station entries, not ambulance events.
Weights in percent (weekday day, weekday night, Shabbat): [{"young": 20.0, "older": 20.0, "jobs": 32.0, "nonres": 5.0, "transit": 16.0, "tourism": 7.0}, {"young": 37.0, "older": 31.0, "jobs": 10.0, "nonres": 4.0, "transit": 12.0, "tourism": 6.0}, {"young": 32.0, "older": 28.0, "jobs": 13.0, "nonres": 5.0, "transit": 14.0, "tourism": 8.0}]
ORSNP Île-de-France and participating fire services, 2023, pages 5–7. Département of intervention and time-of-day chart — https://orsnp-idf.fr/wp-content/uploads/2025/06/Rapport-annuel-pompiers-2023-VF-.pdf
Ville de Paris, 20 municipal arrondissement boundaries — https://opendata.paris.fr/explore/dataset/arrondissements/
IGN and INSEE, IRIS-GE neighbourhood polygons — https://www.data.gouv.fr/datasets/iris-ge
APUR, INSEE 2021 population and age by IRIS. Table iris_2021_population — https://carto2.apur.org/apur/rest/services/OPENDATA/RECENSEMENT_IRIS/MapServer/5
INSEE, 2022 census, workplace employment (EMP4) by municipal arrondissement — https://www.insee.fr/fr/statistiques/8581559
Île-de-France Mobilités, 2023 rail validations by station, date, semester, day type and hour — https://data.iledefrance-mobilites.fr/explore/dataset/histo-validations-reseau-ferre/
Île-de-France Mobilités, station coordinates and zone de correspondance identifiers — https://data.iledefrance-mobilites.fr/explore/dataset/emplacement-des-gares-idf/
Île-de-France Mobilités, method for daily counts and hourly profiles — https://data.iledefrance-mobilites.fr/api/v2/catalog/datasets/histo-validations-reseau-ferre/attachments/donnees_de_validation_pdf
Ville de Paris, published international tourist-zone boundaries — https://opendata.paris.fr/explore/dataset/zones-touristiques-internationales/
European Commission JRC · GHS-POP R2023A, 2020 epoch, 100 m — https://human-settlement.emergency.copernicus.eu/ghs_pop2023.php
European Commission JRC · GHS-BUILT-S R2023A, non-residential surface, 2020 epoch, 100 m — https://human-settlement.emergency.copernicus.eu/ghs_buS2023.php
Van Buuren et al. · demand-point constrained ambulance coverage — https://martinvanbuuren.nl/wp-content/uploads/2020/01/M.-van-Buuren-et-al.-Demand-point-constrained-EMS-vehicle-allocation-problems-for-regions.pdf

Arlington, Texas
59836 / FY2025 / EMS ambulance calls dispatched in the city annual report
City of Arlington, Texas, using its 2020 Census place boundary and inhabited or mixed land/water blocks. Arlington Fire Department reports 59,836 ambulance calls dispatched in FY2025. The local estimates combine 2020 Census residents, 2023 Census LEHD workplace jobs and non-residential building surface. Jobs measure workplace locations, including jobs held by commuters. A 25% share of each period’s allocation uses 2016–17 geocoded AFD medical first-response incidents. The FY2025 report separately lists 62,071 ambulance responses and 42,572 transports.
The 2016–17 fire-service medical first-response record supplies the hour-of-week pattern for the FY2025 ambulance dispatch total. It describes a different year and a subset of responders. The 25% historical spatial signal is also specific to the selected period.
The 2020 Census incorporated-place boundary and Census block internal points identify in-city blocks. Water-only blocks are removed. Mixed land/water blocks retain their polygon boundaries. Jobs are 2023 LODES workplace job counts, not people present at a given hour.
Weights in percent (weekday day, weekday night, Shabbat): [{"pop": 32.0, "jobs": 40.0, "nonres": 3.0, "historical": 25.0}, {"pop": 63.0, "jobs": 9.0, "nonres": 3.0, "historical": 25.0}, {"pop": 56.0, "jobs": 15.0, "nonres": 4.0, "historical": 25.0}]
City of Arlington Fire Department FY2025 annual report — https://www.arlingtontx.gov/News-Articles/2026/May/Arlington-Fire-Department-Publishes-Fiscal-Year-2025-Annual-Report
U.S. Census Bureau TIGERweb Census 2020 incorporated-place boundaries — https://tigerweb.geo.census.gov/arcgis/rest/services/TIGERweb/tigerWMS_Census2020/MapServer/26
U.S. Census Bureau TIGERweb 2020 blocks and POP100 — https://tigerweb.geo.census.gov/arcgis/rest/services/TIGERweb/tigerWMS_Census2020/MapServer/10
U.S. Census Bureau LEHD LODES 2023 workplace jobs, all job types (C000) — https://lehd.ces.census.gov/data/lodes/LODES8/tx/wac/tx_wac_S000_JT00_2023.csv.gz
Arlington Fire Department · historical fire incident data — https://gis2.arlingtontx.gov/agsext2/rest/services/Fire/Fire/MapServer/3
European Commission JRC · GHS-POP R2023A, 2020 epoch, 100 m — https://human-settlement.emergency.copernicus.eu/ghs_pop2023.php
European Commission JRC · GHS-BUILT-S R2023A, non-residential surface, 2020 epoch, 100 m — https://human-settlement.emergency.copernicus.eu/ghs_buS2023.php
Van Buuren et al. · demand-point constrained ambulance coverage — https://martinvanbuuren.nl/wp-content/uploads/2020/01/M.-van-Buuren-et-al.-Demand-point-constrained-EMS-vehicle-allocation-problems-for-regions.pdf

Sioux Falls, South Dakota
21825 / CY2025 / Priority 1–3 emergency calls counted in ambulance compliance reports
Sioux Falls, South Dakota, using the 2020 Census place boundary. The annual count sums all twelve 2025 city ambulance compliance reports. It excludes priority 4–5 interfacility transfers and may exclude contract-exempt calls. Local demand uses 2020 Census block populations, 2023 Census LEHD jobs and non-residential buildings. New development after the 2020 boundary is outside this geography.
The March 2025 city-commissioned EMS assessment gives historical hourly and weekday charts. We combine their normalized shares, assuming the same hourly shape on each weekday, then scale to the 2025 annual count. The plotted values are approximate.
The 2020 Census incorporated-place boundary and Census block internal points identify in-city blocks. Water-only blocks are removed. Mixed land/water blocks retain their polygon boundaries. Jobs are 2023 LODES workplace job counts, not people present at a given hour. The 12 reported compliance denominators exclude Priority 4 and 5 interfacility transfers. Some calls may be exempt under the response-time contract.
Weights in percent (weekday day, weekday night, Shabbat): [{"pop": 42.0, "jobs": 53.0, "nonres": 5.0}, {"pop": 84.0, "jobs": 12.0, "nonres": 4.0}, {"pop": 74.0, "jobs": 21.0, "nonres": 5.0}]
City of Sioux Falls, monthly ambulance response-time reports (all twelve months of 2025) — https://www.siouxfalls.gov/health-safety/fire/about/operations/ems-sf/amb-response-times
U.S. Census Bureau TIGERweb Census 2020 incorporated-place boundaries — https://tigerweb.geo.census.gov/arcgis/rest/services/TIGERweb/tigerWMS_Census2020/MapServer/26
U.S. Census Bureau TIGERweb 2020 blocks and POP100 — https://tigerweb.geo.census.gov/arcgis/rest/services/TIGERweb/tigerWMS_Census2020/MapServer/10
U.S. Census Bureau LEHD LODES 2023 workplace jobs, all job types (C000) — https://lehd.ces.census.gov/data/lodes/LODES8/sd/wac/sd_wac_S000_JT00_2023.csv.gz
Sioux Falls EMS System Assessment · March 2025, hourly pattern, p. 11 — https://www.siouxfalls.gov/files/assets/public/v/1/fire-rescue/fire-ems-rescue/final-ems-system-assessment.pdf#page=12
European Commission JRC · GHS-POP R2023A, 2020 epoch, 100 m — https://human-settlement.emergency.copernicus.eu/ghs_pop2023.php
European Commission JRC · GHS-BUILT-S R2023A, non-residential surface, 2020 epoch, 100 m — https://human-settlement.emergency.copernicus.eu/ghs_buS2023.php
Van Buuren et al. · demand-point constrained ambulance coverage — https://martinvanbuuren.nl/wp-content/uploads/2020/01/M.-van-Buuren-et-al.-Demand-point-constrained-EMS-vehicle-allocation-problems-for-regions.pdf

New York City
1575273 / 2025 / FDNY EMS incidents with a recorded first unit assignment
All five boroughs, using shoreline-clipped 2020 Census tracts. The FDNY 2025 CAD records provide actual assigned incident counts for each reporting precinct and time window. The model distributes each precinct’s workload among its hexagons using residents, workplace jobs and non-residential buildings. Of the 1,575,273 assigned incidents, 15,630 lack a precinct. We redistribute the unmatched records in proportion to known precinct totals within each period. The mapped boundaries use a later precinct release.
2025 assigned incidents in the three local windows numbered 706,882 on weekday days, 343,239 on weekday nights and 226,850 on Shabbat. Hourly rates use the elapsed hours of each window, including local sunset, civil dusk and daylight-saving changes. The windows cover only part of the week.
Boundary is the union of NYC Department of City Planning shoreline-clipped 2020 tracts. All 8,804,190 original 2020 Census residents are included. Two zero-population offshore tracts are excluded. Jobs are 2023 LODES jobs at workplaces, not a count of people present at a given hour.
Weights in percent (weekday day, weekday night, Shabbat): [{"pop": 42.0, "jobs": 53.0, "nonres": 5.0}, {"pop": 84.0, "jobs": 12.0, "nonres": 4.0}, {"pop": 74.0, "jobs": 21.0, "nonres": 5.0}]
NYC Department of City Planning, shoreline-clipped 2020 census tracts — https://data.cityofnewyork.us/City-Government/2020-Census-Tracts/63ge-mke6
U.S. Census Bureau TIGERweb Census 2020 tract population, POP100 — https://tigerweb.geo.census.gov/arcgis/rest/services/TIGERweb/tigerWMS_Census2020/MapServer/6
U.S. Census Bureau LEHD LODES 2023 workplace jobs, all job types (C000) — https://lehd.ces.census.gov/data/lodes/LODES8/ny/wac/ny_wac_S000_JT00_2023.csv.gz
FDNY · EMS Incident Dispatch Data — https://data.cityofnewyork.us/Public-Safety/EMS-Incident-Dispatch-Data/76xm-jjuj
NYC Department of City Planning · police precincts — https://data.cityofnewyork.us/City-Government/Police-Precincts/y76i-bdw7
European Commission JRC · GHS-POP R2023A, 2020 epoch, 100 m — https://human-settlement.emergency.copernicus.eu/ghs_pop2023.php
European Commission JRC · GHS-BUILT-S R2023A, non-residential surface, 2020 epoch, 100 m — https://human-settlement.emergency.copernicus.eu/ghs_buS2023.php
Van Buuren et al. · demand-point constrained ambulance coverage — https://martinvanbuuren.nl/wp-content/uploads/2020/01/M.-van-Buuren-et-al.-Demand-point-constrained-EMS-vehicle-allocation-problems-for-regions.pdf

Tel Aviv–Yafo
Original citywide MDA clinical dispatch baseline, four clinical categories, 2024. Full methods and source links are in the Tel Aviv page.
https://www.mdais.org/media/5356/sicum-shana-2024.pdf#page=9